UT_ASSERT_EQ(ft_sqrt(25), 5);
UT_ASSERT_EQ(ft_sqrt(100), 10);
UT_ASSERT_EQ(ft_sqrt(18), 0);
UT_ASSERT_EQ(ft_sqrt(0), 0);