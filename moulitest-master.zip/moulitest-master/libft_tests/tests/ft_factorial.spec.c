UT_ASSERT_EQ(ft_factorial(0), 1);
UT_ASSERT_EQ(ft_factorial(1), 1);
UT_ASSERT_EQ(ft_factorial(3), 6);
UT_ASSERT_EQ(ft_factorial(5), 120);
UT_ASSERT_EQ(ft_factorial(8), 40320);
UT_ASSERT_EQ(ft_factorial(20), 2432902008176640000);